from .common import *
# Enter your test settings here.

DEBUG = False

CSRF_COOKIE_SECURE = True
SESSION_COOKIE_SECURE = True
SECURE_HSTS_SECONDS=1200
SECURE_HSTS_INCLUDE_SUBDOMAINS=False


