from __future__ import unicode_literals, absolute_import
from django.test import TestCase

class SampleTestCase(TestCase):

    def test_case(self):
        self.assertTrue(True)
