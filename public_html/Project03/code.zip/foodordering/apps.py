from django.apps import AppConfig


class FoodorderingConfig(AppConfig):
    name = 'foodordering'
